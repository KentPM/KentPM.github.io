# timestuff
payrate calculator for BU of the 223/58
